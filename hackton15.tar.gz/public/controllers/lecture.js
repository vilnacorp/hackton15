var displayTab = "HOT";
var currentCourseNumber = "";


$(document).ready(function () {

    $('#hotQuestions').click(function () {
        displayTab = "HOT";
        liveLecture();
    });

    $('#recentQuestions').click(function () {
        displayTab = "RECENT";
        liveLecture();
    });

    $("#answeredQuestions").click(function () {
        displayTab = "ANSWERED";
        liveLecture();
    });

    $("#backToCourse").click(function () {
        $("#courseNumber").val("");
        navigate("lecturePage", "coursePage");
    });

    $('#sendQuestion').click(function () {
        var text = $('#newQuestion').val();
        if (text === "Enter your Question" || text === "") {
            alert("Enter your question before submit");
        } else {
            newQuestion(text, $('#withName').is(':checked'), function () {
                liveLecture();
            })
        }
    });

    $(document).on('change', '.questionLike', updateSingleQuestions);
    $(document).on('change', '.questionAnswered', updateSingleQuestions);

});
function startTimer() {
    setInterval(liveLecture, 10000);
}

function liveLecture() {

    updateQuestions(function (data) {
        updateList(data);
        switch (displayTab) {
            case "HOT":
                questions.sort(compareByVotes);
                var questionsToInject = createQuestionHtml(questions);
                break;
            case "RECENT":
                questions.sort(compareByTime);
                var questionsToInject = createQuestionHtml(questions);
                break;
            case "ANSWERED":
                var questionsToInject = createQuestionHtml(answeredQuestions);
                break;
        }

        $('#questionsArea').children("ul").remove();
        $('#questionsArea').append(questionsToInject);
    });

}


function createQuestionHtml(questions) {
    var checkBoxClass = '';
    if (isAdmin) {
        checkBoxClass = "questionAnswered";
    } else {
        checkBoxClass = "questionLike";
    }
    var template = '<ul class="questionsList" align="center">';
    var isCheck = '';
    for (var i = 0; i < questions.length; i++) {
        var question = questions[i];

        var res = isAdmin ? question.answered : question.voted;

        if (res) {
            isCheck = 'checked';
        } else {
            isCheck = '';
        }
        template
            += '<li class="singleQuestion">'
            + '<span class="questionTime">' + question.time + '</span>'
            + '<span class="questionName">' + question.sender + '</span>'
            + '<span class="questionTitle">' + question.questionTitle + '</span>'
            + '<input type="checkbox" class="' + checkBoxClass + '" id="like' + question.questionId.toString() + '" ' + isCheck + '>'
            + '<span class="questionRanking">' + question.ranking + '</span>'
            + '</li>';
        $('#like' + question.questionId.toString()).change(updateSingleQuestions)

    }

    template += '</ul>';
    return template;
}

function updateSingleQuestions() {

    var questionId = $(this).attr("id");
    var isLike = $(this).is(':checked');
    questionId = questionId.substring(4);
    if (isAdmin) {
        moveToAnswered(questionId, function () {
            liveLecture();
        });
    } else {
        updateSingleRank(questionId, isLike, function () {
            liveLecture();
        });
    }

}

//-------------------------------------------------ajax request------------------------------------------------------


function updateQuestions(callback) {
    $.ajax({
        url: '/backend/session/' + currentCourseNumber,
        type: 'get',
        data: {},
        success: function (data) {
            callback(data);
        }
    })
}


function updateSingleRank(questionId, isLike, callback) {

    $.ajax({
        url: '/backend/session/' + currentCourseNumber + '/question/' + questionId + '/vote',
        type: 'put',
        data: {type: isLike},
        success: function (data) {
            callback(data);
        }

    })
}

function moveToAnswered(questionId, callback) {
    $.ajax({
        url : '/backend/session/' + currentCourseNumber + '/question/' + questionId + '/answer',
        type : 'put',
        data : {},
        success : function(data) {
            callback(data);
        }
    })
}


function newQuestion(text, anonymous, callback) {

    $.ajax({
        url: '/backend/session/' + currentCourseNumber + '/question',
        type: 'post',
        data: {
            questionTitle: text,
            anonymous: anonymous
        },
        success: function (data) {
            callback();
        }
    });

}